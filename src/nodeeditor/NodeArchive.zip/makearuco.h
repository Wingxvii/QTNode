#ifndef MAKEARUCO_H
#define MAKEARUCO_H

#endif // MAKEARUCO_H
//core includes
#include <QtCore/QObject>
#include <nodes/NodeDataModel>
#include <iostream>
#include <sstream>
#include <fstream>

//opencv includes
#include "opencv2/core.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/calib3d.hpp"
#include "opencv2/aruco.hpp"

//qt ui includes
#include <QFileDialog>
#include <QPushButton>
#include <QVBoxLayout>
#include <QComboBox>
#include <QLabel>

//shotcut includes
#include "videographdata.h"

//qt node data
using QtNodes::PortType;
using QtNodes::PortIndex;
using QtNodes::NodeData;
using QtNodes::NodeDataType;
using QtNodes::NodeDataModel;
using QtNodes::NodeValidationState;

class MakeAruco : public NodeDataModel
{
public:


    MakeAruco();
    ~MakeAruco();

    QString caption() const override
    {
        return QStringLiteral("Create Aruco");
    }

    bool captionVisible()
    {
        return false;
    }

    QString name() const override
    {
        return QStringLiteral("Create Aruco");
    }



    unsigned int nPorts(PortType PortType) const override{return 0;}
    NodeDataType dataType(PortType portType, PortIndex portIndex) const override {return VideoGraphData().type();}
    std::shared_ptr<NodeData> outData(PortIndex port) override{return 0;}
    void setInData(std::shared_ptr<NodeData>, int) override{}

    QWidget* embeddedWidget() override {return container;}
    NodeValidationState validationState() const override;
    QString validationMessage() const override;
    bool resizable() const override {return false;}

private:
    void createArucoMarker();


    void setSize(int sizeIndex);
    void setNum(int numIndex);
    void setPixle(int pixelIndex);

    int size = 4;
    int number = 50;
    int pixelSize = 100;

    QPushButton* filebutton;
    QWidget* container;
    QVBoxLayout* layout;
    QComboBox* sizeBox;
    QComboBox* numberBox;
    QComboBox* resolutionBox;

    NodeValidationState modelValidationState = NodeValidationState::Warning;
    QString modelValidationError = QStringLiteral("Cannot be called");



};
