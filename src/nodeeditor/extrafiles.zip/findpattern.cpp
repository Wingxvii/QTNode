#include "findpattern.h"

#include <opencv2/calib3d.hpp>

FindPattern::FindPattern(){
    button = new QPushButton("Find");

    connect(button, SIGNAL(clicked(bool)), this, SLOT(findChessPattern()));

}

unsigned int FindPattern::nPorts(QtNodes::PortType portType) const
{
    unsigned int result = 1;

    switch (portType){
    case PortType::In:
        result = 1;
        break;
    case PortType::Out:
        result = 1;
        break;
    default:
        break;
    }
}
